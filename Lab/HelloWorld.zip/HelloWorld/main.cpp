/* 
 * File:   main.cpp
 * Author: Branden Hitt
 * Created on February 22, 2015, 4:29 PM
 *      Purpose: Our First Program again!
 */

#include <iostream>
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    cout<<"Hello World!"<<endl;
    return 0;
}

