/* 
 * File:   main.cpp
 * Author: Branden Hitt 
 * Created on March 4, 2015, 8:23 AM
 *      Purpose: Output Big CS!
 */
//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    //Input
    //Output Big CS!
    cout<<"******************************************"<<endl;
    cout<<"      c c c           s s s s      !!  "<<endl;
    cout<<"    c      c         s       s     !!  "<<endl;
    cout<<"    c               s              !!  "<<endl;
    cout<<"    c                s             !!  "<<endl;
    cout<<"    c                 s s s s      !!  "<<endl;
    cout<<"    c                        s     !!  "<<endl;
    cout<<"    c                         s    !!  "<<endl;
    cout<<"     c     c         s        s       "<<endl;
    cout<<"      c c c           s s s s      00  "<<endl;
    cout<<"******************************************"<<endl;
    cout<<endl;
    cout<<"Computer Science is Cool Stuff!!!"<<endl;
    //Exit Stage Right
    return 0;
}
